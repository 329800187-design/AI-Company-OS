# AI Company OS - Mac 测试包

Package: AI-company-os-20260727-83aafb2-mac-test
Commit: 83aafb2
Created: 2026-07-27 01:16:47 +08:00

## 这个压缩包包含什么

这是从当前 Git HEAD 导出的源码包，适合复制到另一台 Mac 上测试。

已排除：.git、.env、node_modules、.venv、缓存、日志、测试产物、数据库备份等本机运行产物。

## Mac 快速启动

```bash
unzip AI-company-os-20260727-83aafb2-mac-test.zip
cd AI-company-os-20260727-83aafb2-mac-test
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

编辑 `.env` 填入需要的 API Key；不填时多数本地测试会走 mock/fallback。

启动后端：

```bash
python -m uvicorn backend.app:app --host 0.0.0.0 --port 8000 --reload
```

启动前端：

```bash
cd frontend-new
npm install
npm run dev -- --host 0.0.0.0
```

常用地址：

- API docs: http://localhost:8000/docs
- Frontend: http://localhost:5173

可选验证：

```bash
pytest tests/test_agents_quick.py tests/test_commander.py tests/test_dag_workflow.py tests/test_security_rbac.py tests/test_boss_command_center.py tests/test_graph_template_store.py
cd frontend-new && npm run build
```

Mac 依赖建议：Python 3.10+、Node.js 20+、npm。Playwright 如需浏览器：`python -m playwright install chromium`。

如果 `start.sh` 没有执行权限：

```bash
chmod +x start.sh
./start.sh
```